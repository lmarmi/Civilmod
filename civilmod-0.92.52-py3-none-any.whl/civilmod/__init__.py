#coding:UTF-8
#A:nlvac97
#PN:CIVILMOD
#V:0.92.52A-rel
#FC:main(FIRST)
#PUrl:nlvac97.github.io

INFOES = {"Project Name":"civilmod",
          "Project Author":"Nlvac97",
          "Project Version":"0.92.52A-rel",
          "Project Offical Website":"nlvac97.github.io"}
#__all__ = ("upgrade","getBMI","translate","donothing","pausePrint","openFolder","CivilmodError","captcha","judge")
